package com.wipro.entity;

public enum Role {
	ADMIN,DOCTOR,PATIENT, GROUP, USER

}

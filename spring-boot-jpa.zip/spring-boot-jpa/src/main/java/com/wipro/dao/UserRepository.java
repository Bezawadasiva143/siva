package com.wipro.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/*
 * save(), findById(), findAll(), count(), existsById(), deleteById(), delete(), deleteAll()
 */
import com.wipro.entity.User;

//@Repository
//public interface UserRepository extends CrudRepository<User,Integer>{
//
//}


/*
 * additional methods related to Pagination and Sorting plus methods related to
 * delete record in batch and flushing persistence context
 */
@Repository
public interface UserRepository extends JpaRepository<User,Integer>{

}
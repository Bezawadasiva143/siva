package com.wipro.model;

public enum Role {
	ADMIN,USER,GROUP
}

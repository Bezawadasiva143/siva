package com.wipro.service;
import lombok.Data;
@Data
public class CreateCustomerDto {
   private String firstName;
   private String lastName;
}
